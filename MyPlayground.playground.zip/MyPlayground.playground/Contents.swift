import UIKit

//// Variables, Constants and Literals
//
//var testVariable = 50
//
//testVariable = 60
//var testVariableString = "Test String"
//
//// Constants
//
//let testConstant = 30
//let testConstant2 = 3
//
//testConstant / testConstant2
//
//let testConstant3 = 40
//let testConstant4 = 30
//
//testConstant3 * testConstant4
//
////testConstant = 40
//
//let testConstantStrings = "test string"
//
//// Literals
//
//// Character
//let testCharacter : Character = "s"
//
//// String
//var testString : String = "Cliff"
//testString.append("Nwigwe is good")
//
//// Int
//var testInt : Int = 40
//
//// Bool
//let testBool : Bool = true


// 1). Replace letter “a” inside string with letter “x” in given string “iOS Training Assessment”
var testString : String = "iOS Training Assessment"
testString.replacingOccurrences(of: "a", with: "x")

// 2). Remove string “sess” from string “iOS Training Assessment”
var removeString : String = "iOS Training Assessment"
removeString.replacingOccurrences(of: "sess", with: "")

// Q3: Remove occurence of string "is" from string "This is Pakistan".
var eString = "This is Pakistan"
eString.replacingOccurrences(of: "is", with: "")

// Q4: How can we check first and last element of string?
let givenString = "This is Nigeria"
givenString.first
givenString.last

// Q5: Divide 45 with 30 and check answer. Explain why answer is int.
45/30  //Explanation: The result was 1 because no data type of Double and Float was initiated, to get .5 we have to add the data type double

var firstNum = Double(45);
var secondNum = Double (30);

firstNum/secondNum


// Q6: Check max decimal point limit in float and double types.
//The float data type has only 6-7 decimal digits of precision.
//A double data type has 15 decimal digits of accuracy if they are all before the decimal point.

